Background Slicer created by thant.
______________________________________
To Load Action:
Copy Wallpaper Slicer.atn to you photohop/presets/photoshop actions folder. 
Go into photoshop and select window>actions palette. 
Click the arrow in a circle and select load actions. Locate Wallpaper Slicer.atn.
_______________________________________
For help contact me at thantophobia@hotmail.com
_______________________________________
Please visit:
http://www.steamskinners.com
http://thantophobia.coolfreepages.com
http://www.steampowered.com